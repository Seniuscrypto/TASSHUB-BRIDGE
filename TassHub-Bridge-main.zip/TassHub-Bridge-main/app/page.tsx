"use client"

import CrossChainBridge from "./bridge-dapp"

export default function Page() {
  return <CrossChainBridge />
}
